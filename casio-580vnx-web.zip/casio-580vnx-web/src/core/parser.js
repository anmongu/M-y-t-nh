/* Safe recursive-descent parser. No eval() or Function(). */
(function(global){
  const MAX_LENGTH=240;
  function tokenize(input){
    if(typeof input!=='string'||input.length>MAX_LENGTH) throw Error('Biểu thức quá dài.');
    const s=input.replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/π/g,'pi').replace(/Ans/g,'ans');
    const out=[];let i=0;
    while(i<s.length){if(/\s/.test(s[i])){i++;continue;}const rest=s.slice(i);let m;
      if((m=/^(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?/.exec(rest))){out.push({type:'num',value:Number(m[0]),raw:m[0]});i+=m[0].length;continue;}
      if((m=/^[a-zA-Z]+/.exec(rest))){const name=m[0].toLowerCase();if(!['sin','cos','tan','asin','acos','atan','sinh','cosh','tanh','sqrt','abs','log','ln','exp','floor','ceil','round','pi','e','ans','x','y','z'].includes(name))throw Error('Hàm hoặc tên biến chưa được hỗ trợ: '+m[0]);out.push({type:'name',value:name});i+=m[0].length;continue;}
      if('+-*/^!()'.includes(s[i])){out.push({type:s[i]==='('? 'lparen':s[i]===')'?'rparen':s[i]==='!'?'fact':'op',value:s[i]});i++;continue;}
      throw Error('Ký tự không hợp lệ: '+s[i]);
    }
    // Explicit implicit multiplication, e.g. 2pi, 2(3+4), (2)(3).
    const fixed=[];for(let j=0;j<out.length;j++){const a=fixed[fixed.length-1],b=out[j];if(a&&((a.type==='num'||a.type==='name'||a.type==='rparen'||a.type==='fact')&&(b.type==='name'||b.type==='lparen'))&&!(a.type==='name'&&['sin','cos','tan','asin','acos','atan','sinh','cosh','tanh','sqrt','abs','log','ln','exp','floor','ceil','round'].includes(a.value)))fixed.push({type:'op',value:'*'});fixed.push(b);}return fixed;
  }
  function parse(input){const t=tokenize(input);let p=0;const peek=()=>t[p],take=()=>t[p++];
    function primary(){const x=take();if(!x)throw Error('Thiếu toán hạng.');if(x.type==='num')return {type:'num',value:x.value};if(x.type==='name'){
      if(['pi','e','ans','x','y','z'].includes(x.value))return {type:'const',value:x.value};
      if(peek()?.type!=='lparen')throw Error('Cần dấu ( sau '+x.value+'.');take();const arg=expr(0);if(take()?.type!=='rparen')throw Error('Thiếu dấu đóng ngoặc.');return {type:'call',name:x.value,arg};}
      if(x.type==='lparen'){const n=expr(0);if(take()?.type!=='rparen')throw Error('Thiếu dấu đóng ngoặc.');return n;}
      if(x.type==='op'&&(x.value==='+'||x.value==='-'))return {type:'unary',op:x.value,arg:expr(25)};
      throw Error('Cú pháp không hợp lệ.');}
    const prec={'+' :10,'-':10,'*':20,'/':20,'^':30};
    function expr(min){let left=primary();while(peek()) {const tok=peek();if(tok.type==='fact'){if(40<min)break;take();left={type:'fact',arg:left};continue;}if(tok.type!=='op'||!(tok.value in prec)||prec[tok.value]<min)break;take();const op=tok.value;const right=expr(prec[op]+(op==='^'?0:1));left={type:'binary',op,left,right};}return left;}
    if(!t.length)throw Error('Hãy nhập biểu thức.');const tree=expr(0);if(p<t.length)throw Error('Biểu thức có phần chưa được hiểu.');return tree;
  }
  function evaluate(ast,ctx={}){const finite=x=>{if(!Number.isFinite(x))throw Error('Kết quả không xác định hoặc vượt phạm vi.');return x;};const angle=ctx.angle||'DEG';const trig=x=>angle==='DEG'?x*Math.PI/180:angle==='GRAD'?x*Math.PI/200:x;const inv=x=>angle==='DEG'?x*180/Math.PI:angle==='GRAD'?x*200/Math.PI:x;
    switch(ast.type){case'num':return ast.value;case'const':return ast.value==='pi'?Math.PI:ast.value==='e'?Math.E:ast.value==='ans'?finite(Number(ctx.ans||0)):finite(Number((ctx.vars||{})[ast.value]||0));case'unary':return ast.op==='-'?-evaluate(ast.arg,ctx):evaluate(ast.arg,ctx);case'fact':{const x=evaluate(ast.arg,ctx);if(!Number.isInteger(x)||x<0||x>170)throw Error('Giai thừa cần số nguyên từ 0 đến 170.');let r=1;for(let i=2;i<=x;i++)r*=i;return finite(r);}case'binary':{const a=evaluate(ast.left,ctx),b=evaluate(ast.right,ctx);switch(ast.op){case'+':return finite(a+b);case'-':return finite(a-b);case'*':return finite(a*b);case'/':if(b===0)throw Error('Không thể chia cho 0.');return finite(a/b);case'^':return finite(a**b);}}case'call':{const x=evaluate(ast.arg,ctx);switch(ast.name){case'sin':return finite(Math.sin(trig(x)));case'cos':return finite(Math.cos(trig(x)));case'tan':if(Math.abs(Math.cos(trig(x)))<1e-14)throw Error('Tan không xác định tại góc này.');return finite(Math.tan(trig(x)));case'asin':if(Math.abs(x)>1)throw Error('Ngoài miền xác định.');return inv(Math.asin(x));case'acos':if(Math.abs(x)>1)throw Error('Ngoài miền xác định.');return inv(Math.acos(x));case'atan':return inv(Math.atan(x));case'sinh':return Math.sinh(x);case'cosh':return Math.cosh(x);case'tanh':return Math.tanh(x);case'exp':return finite(Math.exp(x));case'floor':return Math.floor(x);case'ceil':return Math.ceil(x);case'round':return Math.round(x);case'sqrt':if(x<0)throw Error('Căn bậc hai của số âm không thuộc Calculate thực.');return Math.sqrt(x);case'abs':return Math.abs(x);case'log':if(x<=0)throw Error('Logarit cần đối số dương.');return Math.log10(x);case'ln':if(x<=0)throw Error('Logarit tự nhiên cần đối số dương.');return Math.log(x);}}}throw Error('Không thể tính biểu thức này.');}
  function calculate(input,ctx){const ast=parse(input);return {ast,value:evaluate(ast,ctx)};}
  global.CalculatorCore={tokenize,parse,evaluate,calculate};
})(window);
